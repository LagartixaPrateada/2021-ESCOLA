# JavaScript-AtividadeCTII148
CB3014312 | CTII148 | 19/10/21 | ATIVIDADE JAVASCRIPT 
Elabore um documento HTML com seu respectivo código Javascript no sentido de atender às especificações de cada item abaixo.
