﻿using System;

namespace PIPOCA
{
    class Program
    {
        static void Main(string[] args)
        {
            //Mariana Prata Leite 148
            Console.WriteLine("                              ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("          P");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("          I");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("          P");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("          O");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("          C");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("          A");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("          !");
            Console.ResetColor();
            Console.WriteLine("                              ");
            Console.WriteLine("                             Loading… [][][][][][][][][] 0%");
            Console.WriteLine("                              ");
            Console.WriteLine("                             Loading… ██[][][][][][][][] 20%");
            Console.WriteLine("                              ");
            Console.WriteLine("                             Loading… ████[][][][][][][] 40%");
            Console.WriteLine("                              ");
            Console.WriteLine("                             Loading… ██████[][][][][][] 50%");
            Console.WriteLine("                              ");
            Console.WriteLine("                             Loading… ██████████[][][][] 90%");
            Console.WriteLine("                              ");
            Console.WriteLine("                             Loading… ██████████████████ 100%");
            Console.WriteLine("                              ");
            Console.WriteLine("                              ");
            Console.Write("              Para continuar pressione ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("'qualquer tecla'");
            Console.ReadKey();
            Console.ResetColor();
            Console.WriteLine("                              ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("              PIPOCA! - Feito por Mariana Prata Leite 148");
            Console.ResetColor();
            Console.WriteLine("                              ");
            Console.ResetColor();
            Console.WriteLine("                              ");
            //////////////////////////////////////////////////////////////////////////////////////////////////
            Console.WriteLine("              São quatro horas da manhã, você estava jogando um jogo no seu computador até que derrepente...");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("              Grrrrrrh - sua barriga");
            Console.ResetColor();
            Console.WriteLine("              É fome, você não comeu nada dês das oito horas da noite de ontem.");
            Console.WriteLine("              Você é viciado em jogos e esquece até da própria cabeça por isso.");
            Console.WriteLine("              Sem muita variedade no cardápio, nada mais resta do que fazer pipoca, a boa e velha (e rápida) pipoca.");
            Console.WriteLine("              Vamos fazer uma pipoca!");
            Console.WriteLine("                              ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("                              ");
            Console.WriteLine("                     Você vai precisar de:");
            Console.WriteLine("                     Uma panela;");
            Console.WriteLine("                     Grãos de milho para pipoca;");
            Console.WriteLine("                     Oléo de cozinha.");
            Console.WriteLine("                              ");
            Console.ResetColor();
            //////////////////////////////////////////////////////////////////////////////////////////////////
            Console.WriteLine("              Você está na cozinha, qual o lugar que você deve procurar por uma panela?");
            PUM:
            Console.Write("              Procurar no ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("armário de guardar panelas");
            Console.ResetColor();
            Console.Write(" ou procurar no ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("escorredor");
            Console.ResetColor();
            Console.Write("? ");
            Console.ForegroundColor = ConsoleColor.Blue;
            string pume = Console.ReadLine();
            Console.ResetColor();
            switch (pume)
            {
                case "armário de guardar panelas":
                goto ARMAUM;
                case "escorredor":
                goto ESCORREDOR;
                default:
                goto PUM;
                
            }
            ARMAUM:
            Console.WriteLine("                              ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("              Armário de guardar panelas.");
            Console.ResetColor();
            Console.WriteLine("              É, certamente devia estar aqui, mas você é o humano mais preguiçoso que existe... um humano que não guarda as coisas, por isso não tem nada aqui.");
            ARMA:
            Console.Write("              Digite ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("oh como sou abobado");
            Console.ResetColor();
            Console.Write(" para continuar: ");
            Console.ForegroundColor = ConsoleColor.Blue;
            string abobado = Console.ReadLine();
            Console.ResetColor();
            switch (abobado)
            {
                case "oh como sou abobado":
                goto PUM;
                default:
                goto ARMA;
                
            }
            //////////////////////////////////////////////////////////////////////////////////////////////////
            ESCORREDOR:
            Console.WriteLine("                              ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("              Escorredor.");
            Console.ResetColor();
            Console.WriteLine("              Sim claro, não podia estar em outro lugar... Acho melhor ao menos secar essa panela antes de usar.");
            ESCORRE:
            Console.Write("              Digite ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("oh como sou abobado");
            Console.ResetColor();
            Console.Write(" para continuar: ");
            Console.ForegroundColor = ConsoleColor.Blue;
            string abobadodois = Console.ReadLine();
            Console.ResetColor();
            switch (abobadodois)
            {
                case "oh como sou abobado":
                goto PDOIS;
                default:
                goto ESCORRE;
                
            }
            //////////////////////////////////////////////////////////////////////////////////////////////////
            PDOIS:
            Console.WriteLine("                              ");
            Console.WriteLine("              Você está na cozinha, qual o lugar que você deve procurar os grãos de milho?");
            PUMM:
            Console.Write("              Procurar no ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("armário de guardar alimentos");
            Console.ResetColor();
            Console.Write(" ou procurar na ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("sacola de compras");
            Console.ResetColor();
            Console.Write("? ");
            Console.ForegroundColor = ConsoleColor.Blue;
            string pdois = Console.ReadLine();
            Console.ResetColor();
            switch (pdois)
            {
                case "armário de guardar alimentos":
                goto ARMADOIS;
                case "sacola de compras":
                goto SACOLA;
                default:
                goto PUMM;
                
            }
            ARMADOIS:
            Console.WriteLine("                              ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("              Armário de guardar alimentos.");
            Console.ResetColor();
            Console.WriteLine("              Ontem você foi no mercado, comprou miojo e grãos de pipoca, mas não tem nada guardado aqui, porquê você é um humano que não guarda as coisas, por isso não              tem nada aqui.");
            ARMAD:
            Console.Write("              Digite ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("oh como sou abobado");
            Console.ResetColor();
            Console.Write(" para continuar: ");
            Console.ForegroundColor = ConsoleColor.Blue;
            string abobadotres = Console.ReadLine();
            Console.ResetColor();
            switch (abobadotres)
            {
                case "oh como sou abobado":
                goto PUMM;
                default:
                goto ARMAD;
                
            }
            SACOLA:
            Console.WriteLine("                              ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("              Sacola de compras.");
            Console.ResetColor();
            Console.WriteLine("              Sim claro, não podia estar em outro lugar... Uh? A sacola está furada?! Dois, três, qua-quatro? OH CARA VOCÊ PERDEU ALGUNS OS MIOJOS NA RUA!");
            Console.WriteLine("              Pelo menos temos o grão do milho para a pipoca, e continuamos com quatro pacotes de miojo.");
            SACO:
            Console.Write("              Digite ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("oh como sou abobado");
            Console.ResetColor();
            Console.Write(" para continuar: ");
            Console.ForegroundColor = ConsoleColor.Blue;
            string abobadoquatro = Console.ReadLine();
            Console.ResetColor();
            switch (abobadoquatro)
            {
                case "oh como sou abobado":
                goto PTRES;
                default:
                goto SACO;
                
            }
            //////////////////////////////////////////////////////////////////////////////////////////////////
            PTRES:
            Console.WriteLine("                              ");
            Console.WriteLine("              Você está na cozinha, qual o lugar que você deve procurar o oléo?");
            PUMMM:
            Console.Write("              Procurar no ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("armário de guardar alimentos");
            Console.ResetColor();
            Console.Write(" ou procurar na ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("sacola de compras");
            Console.ResetColor();
            Console.Write("? ");
            Console.ForegroundColor = ConsoleColor.Blue;
            string pdoiss = Console.ReadLine();
            Console.ResetColor();
            switch (pdoiss)
            {
                case "armário de guardar alimentos":
                goto ARMATRES;
                case "sacola de compras":
                goto SACOLAS;
                default:
                goto PUMMM;
                
            }
            ARMATRES:
            Console.WriteLine("                              ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("              Armário de guardar alimentos.");
            Console.ResetColor();
            Console.WriteLine("              Eu já disse que não tem nada guardado aqui...");
            ARMADO:
            Console.Write("              Digite ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("oh como sou abobado");
            Console.ResetColor();
            Console.Write(" para continuar: ");
            Console.ForegroundColor = ConsoleColor.Blue;
            string abobadotress = Console.ReadLine();
            Console.ResetColor();
            switch (abobadotress)
            {
                case "oh como sou abobado":
                goto PUMMM;
                default:
                goto ARMADO;
                
            }
            SACOLAS:
            Console.WriteLine("                              ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("              Sacola de compras.");
            Console.ResetColor();
            Console.WriteLine("              Você comprou miojo e milho, nada mais...");
            Console.WriteLine("              OH CARA, VOCÊ NÃO TEM OLÉO NEM MARGARINA, COMO É QUE VOCÊ VAI FAZER ESSA PIPOCA?.");
            SACAO:
            Console.Write("              Digite ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("achar uma solução");
            Console.ResetColor();
            Console.Write(" ou ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("desistir");
            Console.ResetColor();
            Console.Write(" para continuar: ");
            Console.ForegroundColor = ConsoleColor.Blue;
            string abobadocinco = Console.ReadLine();
            Console.ResetColor();
            switch (abobadocinco)
            {
                case "achar uma solução":
                goto SOLU;
                case "desistir":
                goto DESES;
                default:
                goto SACAO;
                
            }
            //////////////////////////////////////////////////////////////////////////////////////////////////
            SOLU:
            Console.WriteLine("                              ");
            Console.Write("              O que você sujere?");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write(" ex: 'fazer bolo'. ");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Blue;
            string solução = Console.ReadLine();
            Console.ResetColor();
            switch (solução)
            {
                case "fazer miojo":
                goto MIOJO;
                default:
                goto ARROZ;
                
            }
            ARROZ:
            Console.WriteLine("              Cara você é burro?! não tem isso só miojo.");
            Console.Write("              Escreva ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("continuar");
            Console.ResetColor();
            Console.Write(" para tentar novamente: ");
            Console.ForegroundColor = ConsoleColor.Blue;
            string soluçãoo = Console.ReadLine();
            Console.ResetColor();
            switch (soluçãoo)
            {
                case "continuar":
                goto SOLU;
                default:
                goto ARROZ;
                
            }
            MIOJO:
            Console.WriteLine("                              ");
            Console.WriteLine("              Fazer miojo? Olha podemos tentar...");
            Console.WriteLine("                              ");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("              Você pega um pote e o pacote de miojo, abre o pacote e coloca o miojo no pote, só falta a água...");
            Console.ResetColor();
            Console.WriteLine("                              ");
            Console.WriteLine("              Não tem água? ORA NÃO ME DIGA QUE VOCÊ NÃO PAGOU A CONTA QUE ESTAVA ATRASADA?!");
            Console.WriteLine("              Seu idiota! Nem um jogo descente e simples de fazer a merda de uma pipoca eu posso com você! >:(");
            IDIOTA:
            Console.Write("              Peça '");  
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("desculpa por ser idiota");
            Console.ResetColor();
            Console.Write("' ao console: ");
            Console.ForegroundColor = ConsoleColor.Blue;
            string idiota = Console.ReadLine();
            Console.ResetColor();
            switch (idiota)
            {
                case "desculpa por ser idiota":
                goto FIM;
                default:
                goto IDIOTA;
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////
            DESES:
            Console.WriteLine("                              ");
            Console.WriteLine("              Seu preguiçoso! Isso vai lá jogar seu joguinho com fome ou ir chorar a morte da bezerra >:(");
            PREGUIÇOSO:
            Console.Write("              Peça '");  
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("desculpa por ser preguiçoso");
            Console.ResetColor();
            Console.Write("' ao console: ");
            Console.ForegroundColor = ConsoleColor.Blue;
            string preguiçosoo = Console.ReadLine();
            Console.ResetColor();
            switch (preguiçosoo)
            {
                case "desculpa por ser preguiçoso":
                goto FIM;
                default:
                goto PREGUIÇOSO;
            }

            

            FIM:
            Console.WriteLine("              Abobado! Saia daqui te odeio!!! >:(");
 






        }
    }
}
