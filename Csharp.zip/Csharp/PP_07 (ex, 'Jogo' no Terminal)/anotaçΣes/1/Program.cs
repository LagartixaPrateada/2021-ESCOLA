﻿using System;

namespace _1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Cor
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("C");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("h");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("a");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("v");
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.Write("e");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.Write("? ");
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.Write("O");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("N");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("D");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("E?");
            Console.Write(" ");
            Console.ResetColor();

            Console.WriteLine("Você está atrasado para o trabalho, e na correria acabou esquecendo a chave do seu carro em algum lugar da casa!");
            Console.Write(".");
            Console.Write(".");
            Console.Write(".");
            Console.WriteLine(" ") ;

            Sala:
            Console.Write("Encontre as chaves!" );
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(" O mais rápido possível!");
            Console.ResetColor();

            Console.Write("Na sala existe uma ");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("estante ");
            Console.ResetColor();
            Console.Write("de livros, e uma ");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("mesa");
            Console.ResetColor();
            Console.Write(" com ");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("gavetas");
            Console.ResetColor();
            Console.Write(".");
            Console.WriteLine(" Onde quer procurar? Se já achou qual a cor do chaveiro de coração da chave?");
            Console.ForegroundColor = ConsoleColor.Yellow;
            string agir = Console.ReadLine();
            Console.ResetColor();

            switch (agir)
            {
              case "gavetas":
              goto Gaveta;
              
              case "mesa":
              goto Mesa;
              
              case "estante":
              goto Estante;
              
              case "laranja":
              Console.ForegroundColor = ConsoleColor.Magenta;
              Console.WriteLine("Agora você pode usar o carro!");
              Console.ResetColor();
              goto fim;
              
              default:
            Console.ForegroundColor = ConsoleColor.Red;  
            Console.WriteLine("Procure em algum lugar da casa.");
            Console.ResetColor();
            goto Sala;
            } 

            Mesa: 
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Não tem nada aqui... Procure em outro lugar.");
            Console.ResetColor();
            goto Sala;

            Estante: 
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Não tem nada aqui... Procure em outro lugar.");
            Console.ResetColor();
            goto Sala;

            Gaveta:
            Console.Write("São três gavetas... Escola uma ");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("(g1, g2, g3) ou digite voltar ");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Yellow;
            string gavetaescolhida = Console.ReadLine();
            Console.ResetColor();

            switch (gavetaescolhida)
            {   case "g1":
                case "g2":
                Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("Não tem nada aqui...");
                    Console.ResetColor();
                    goto Gaveta;
                case "g3":
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.Write("Você achou a chaves! Que lindo chaveiro ");
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.Write("laranja");
                        Console.ResetColor();
                        Console.WriteLine("!");
                        Console.ResetColor();
                    goto Gaveta;
                case "voltar":
                    goto Sala;
                default:
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                    Console.WriteLine("Procure em algum lugar da casa...");
                    Console.ResetColor();
                    goto Gaveta;
            }

            fim:

            Console.Write("Você conseguiu chegar no trabalho, ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("mas não foi a tempo... Descontaram 10% do seu salário.");


        }
    }
}
