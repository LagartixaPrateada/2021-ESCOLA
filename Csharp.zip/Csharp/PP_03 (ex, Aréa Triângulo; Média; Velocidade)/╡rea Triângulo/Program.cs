﻿using System;

namespace Área_Triângulo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Qual a base do triângulo?");
            string entrada = Console.ReadLine();
            double baset = double.Parse(entrada);

            Console.WriteLine("Qual a altura do triângulo?");
            entrada = Console.ReadLine();
            double alturat = double.Parse(entrada);

            double area = (baset * alturat) / 2;
            Console.WriteLine("Área do trângulo é {0}", area);
        }
    }
}
