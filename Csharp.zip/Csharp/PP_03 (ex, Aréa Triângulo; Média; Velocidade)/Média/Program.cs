﻿using System;

namespace Média
{
    class Program
    {
        static void Main(string[] args)
        {
        
            Console.WriteLine("Quantos bimestres?");
            string entrada = Console.ReadLine();
            double bimestre = double.Parse(entrada);

            Console.WriteLine("Qual a nota do primeiro?");
            entrada = Console.ReadLine();
            double nota = double.Parse(entrada);

            Console.WriteLine("Qual a nota segundo?");
            entrada = Console.ReadLine();
            double nota2 = double.Parse(entrada);

            Console.WriteLine("Qual a nota terceiro?");
            entrada = Console.ReadLine();
            double nota3 = double.Parse(entrada);

            Console.WriteLine("Qual a nota quarto");
            entrada = Console.ReadLine();
            double nota4 = double.Parse(entrada);

            double Média = (nota+nota2+nota3+nota4) / bimestre;

            Console.WriteLine("A média é {0}", Média);

        }
    }
}
