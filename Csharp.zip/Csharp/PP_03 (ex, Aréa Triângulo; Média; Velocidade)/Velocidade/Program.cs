﻿using System;

namespace Velocidade
{
    class Program
    {
        static void Main(string[] args)
        {
        
            Console.WriteLine("Qual a distância percorrida?");
            string entrada = Console.ReadLine();
            double distancia = double.Parse(entrada);

            Console.WriteLine("Quanto tempo?");
            entrada = Console.ReadLine();
            double tempo = double.Parse(entrada);

            double velocidade = (distancia / tempo);

            Console.WriteLine("A velocida é {0}km/h", velocidade);
        }
    }
}
