﻿using System;
using System.Net;
using System.Text.Json.Nodes;

string nome = args[0];
string cep = args[1];
string elemento = args[2];

var cliente = new HttpClient();
string textoJson = await cliente.GetStringAsync($"https://api.postmon.com.br/v1/cep/{cep}");

var obj = JsonNode.Parse(textoJson);

Console.WriteLine("Destinatário: {0}", args[0]);
Console.WriteLine("{0}, {1}", obj?["logradouro"], args[2]);
Console.WriteLine("{0}, {1}-{2}", obj?["bairro"], obj?["cidade"], obj?["estado"]);
Console.WriteLine("CEP: {0}", cep);
