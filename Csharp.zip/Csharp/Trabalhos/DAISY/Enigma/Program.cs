﻿using System;

namespace Enigma
{
    class Program
    {
        static void PalavraDestaque(string palavra, ConsoleColor cor = ConsoleColor.Yellow)
        {   
            Console.ForegroundColor = cor;
            Console.Write(palavra);
            Console.ResetColor();
        }
         static void Loading()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(" Loading… [][][][][][][][][] 0%");
            Console.WriteLine("                            ");
            Console.WriteLine(" Loading… ██[][][][][][][][] 20%");
            Console.WriteLine("                            ");
            Console.WriteLine(" Loading… ████[][][][][][][] 40%");
            Console.WriteLine("                            ");
            Console.WriteLine(" Loading… ██████[][][][][][] 50%");
            Console.WriteLine("                            ");
            Console.WriteLine(" Loading… ██████████[][][][] 90%");
            Console.WriteLine("                            ");
            Console.WriteLine(" Loading… ██████████████████ 100%");
            Console.WriteLine("                            ");
            Console.WriteLine(" Feito por Mariana Prata Leite 148");
            Console.ResetColor();
            Console.Write(" ~Para continuar pressione ");
            PalavraDestaque("qualquer tecla");
            Console.ReadKey();
            Console.WriteLine("             ");
        }
        static void Enigma()
        {
            Console.WriteLine("  Preste atenção, resolva os enigmas.");
            Console.WriteLine(" -Olá, me chamo Lugord, me chame de Sra.Lugord. Aqui vão as palavras necessárias para você conseguir me ajudar:");
        }
        static void Enigmaum()
        {
            Console.WriteLine("                  ");
            Console.WriteLine("  Peludo por fora,");
            Console.WriteLine("  Peludo por dentro,");
            Console.WriteLine("  Passa a perna,");
            Console.WriteLine("  E mete-a dentro.");
            Console.WriteLine("  O que é?");
            PalavraDestaque("  | Casaco | Tênis | Calça |");
            Console.WriteLine("  Responda com (| A | B | C |)");
            Console.ForegroundColor = ConsoleColor.Green; 
            string EnigmaUm =  Console.ReadLine();
            Console.ResetColor(); 
            switch (EnigmaUm)
            {
            case "A":
            {
                Console.WriteLine("Você não fez a escolha certa.");
                Enigmaum();
                return;
            }   
            case "B":
            {
                Console.WriteLine("Você não fez a escolha certa.");
                Enigmaum();
                return;
            }   
            case "C":
            {
                Console.WriteLine(" -Correto.");
                UsodoEnigmaUm();
                return;
            }   
            default:
                Enigmaum();
                return;
            }
        }
        static void UsodoEnigmaUm()
        {
            Console.WriteLine("  O que fazer com essa calça? Bom...");
            Console.WriteLine(" -Preciso de um pedaço de linha e tenho certeza que você pode achar algum fio solto naquela calça, que calça? Uma calça jeans que... eu não sei onde está.");
            Console.WriteLine("  Você vai procura-la após desvendar os outros enigmas.");
        }    
        static void EnigmaDois()
        {
            Console.WriteLine("                  ");
            Console.WriteLine("  Qual é a coisa, qual é ela, Mal entra em casa, põe-se à janela?");
            PalavraDestaque("  | Garrafa | Botão | Janela |");
            Console.WriteLine("  Responda com (| A | B | C |)");
            Console.ForegroundColor = ConsoleColor.Green; 
            string EnigmaUm =  Console.ReadLine();
            Console.ResetColor(); 
            switch (EnigmaUm)
            {
            case "A":
            {
                Console.WriteLine("Você não fez a escolha certa.");
                EnigmaDois();
                return;
            }   
            case "C":
            {
                Console.WriteLine("Você não fez a escolha certa.");
                EnigmaDois();
                return;
            }   
            case "B":
            {
                Console.WriteLine(" -Correto.");
                UsodoEnigmaDois();
                return;
            }   
            default:
                EnigmaDois();
                return;
            }
        }
        static void UsodoEnigmaDois()
        {
            Console.WriteLine("  O que fazer com esse botão? Bom...");
            Console.WriteLine(" -Preciso de um botão, perdi o botão do meu casaco. Talvez a calça e botão estejam no quarto.");
            Console.WriteLine("  Você vai procura-lo mais tarde."); 
        }
        static void Procura()
        {
            Console.WriteLine("              ");
            Console.WriteLine("  Busque os objetos necessários | Calça (linha)| Botão |.");
            Console.WriteLine("  Qual quer buscar primeiro? (| A | B | C - digite C para já encontrei |)");
            Console.ForegroundColor = ConsoleColor.Green;
            string Procurando = Console.ReadLine();
            Console.ResetColor();
            switch (Procurando)
            {
                case "A":
                {
                    Calca();
                    return;
                }
                case "B":
                {
                    Botao();
                    return;
                }
                case "C":
                {
                    Confirmação();
                    return;
                }
                default:
                    Procura();
                    return;
            }
        }
        static void Calca()
        {
            Console.WriteLine("               ");
            Console.Write(" ~Você está no");
            PalavraDestaque(" QUARTO ");
            Console.WriteLine("procurando a calça~");

            Console.Write(" Aqui temos uma ");
            PalavraDestaque("cama");
            Console.Write(" e uma ");
            PalavraDestaque("cadeira");
            Console.WriteLine(".");

            Console.Write(" Para onde você vai? Escolha:");
            PalavraDestaque("(cama | cadeira)");
            Console.WriteLine("  Responda com (| A | B |)");
            Console.ForegroundColor = ConsoleColor.Green;
            string escolha = Console.ReadLine();
            Console.ResetColor();

            switch (escolha)
            {
                case "A":
                {
                    Console.WriteLine("  Você procurou em cima e em baixo da cama, entre os cobertores e até as quinas, não tem calça aqui não.");
                    Calca();
                    return;
                }
                case "B":
                {
                    Console.WriteLine("  Você se virou e viu uma pilha de roupas em uma 'Cadeira' que fica no canto do quarto, lá estava a calça sorroupada!");
                    Procura();
                    return;
                }
                default:
                {
                    Calca();
                    return;
                }
            }
        }
        static void Botao()
        {
            Console.WriteLine("               ");
            Console.Write(" ~Você está no");
            PalavraDestaque(" QUARTO ");
            Console.WriteLine("procurando o botão~");

            Console.Write(" Aqui temos uma ");
            PalavraDestaque("gaveta");
            Console.Write(" e uma ");
            PalavraDestaque("mesa");
            Console.WriteLine(".");

            Console.Write(" Para onde você vai? Escolha:");
            PalavraDestaque("(gaveta | mesa)");
            Console.WriteLine("  Responda com (| A | B |)");
            Console.ForegroundColor = ConsoleColor.Green;
            string escolha = Console.ReadLine();
            Console.ResetColor();

            switch (escolha)
            {
                case "A":
                {
                    Console.WriteLine("  Você procurou na 'Gaveta' da penteadeira, o botão se encontrava lá em baixo de algumas contas que não foram pagas.");
                    Procura();
                    return;
                }
                case "B":
                {
                    Console.WriteLine("  Você procurou em cima e em baixo da mesa, não tinha nada por lá.");
                    Botao();
                    return;
                }
                default:
                {
                    Botao();
                    return;
                }
            }
        }
        static void Confirmação()
        {
            Console.WriteLine("  Se achou mesmo me diga então: onde estava a calça e o botão?");
            PalavraDestaque("  Responda como: 'Onde estava a chave e a máscara? Chaveiro e Mesa' e não: 'Onde estava a chave e o botão? Pendurada no chaveiro e em cima da mesa'");
            Console.WriteLine(".");
            Console.ForegroundColor = ConsoleColor.Green;
            string respostaum = Console.ReadLine();
            Console.ResetColor();

            switch (respostaum)
            {
                case "Cadeira e Gaveta":
                {
                Fim();
                return;
                }
                default:
                Procura();
                return;
            }    
        }
        static void Fim()
        {
            Console.WriteLine("  Então com esses objetos... o 'carinha' terá que fazer o que para poder te ajudar?");
            Console.Write("  _Derrepente a senhora arrancou um fio de linha que estava meio solto da calça, sacou uma agulha de seu bolso e pegou o botão da minha mão; depois de alguns curtos minutos ela tinha novamente um botão no seu casaco.");
            Console.WriteLine("  Então você já sabia como se ajudar? Porque pediu ajuda do 'carinha'?");
            Console.WriteLine(" -Ora, queria que ele forçasse a cuca um pouco com os enigmas e andasse um pouco pela casa, foi divertido que eu sei.");
        }
        static void Main(string[] args)
        {
            Console.WriteLine("  Olá 'carinha' ajude a Sra.Lugord.");
            Console.WriteLine("  Para isso descubra 'no que' ajudar, Sra.Lugord é misteriosa e gosta de enigmas a toda hora.");
            Loading();
            Enigma();
            Enigmaum();
            EnigmaDois();
            Procura();
            Fim();
            Console.WriteLine("  _Essa Senhora, me fez de abobado!");
        }
    }
}
