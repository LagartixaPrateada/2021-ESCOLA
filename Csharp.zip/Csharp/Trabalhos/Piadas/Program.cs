﻿using System.Text.Json.Nodes;

Console.WriteLine();
Console.WriteLine("API JOKES");
Console.ForegroundColor = ConsoleColor.Yellow;
Console.WriteLine("☻ Para buscar uma piada aleatória: /random ");
Console.WriteLine("☻ Para limitar a categoria: /random?limitTo=Array ");
Console.ForegroundColor = ConsoleColor.Magenta;
Console.WriteLine("ex: /random?limitTo=[nerdy,explicit]");
Console.WriteLine();
Console.ForegroundColor = ConsoleColor.Red;
Console.WriteLine("|| As categorias são: nerdy , explicit , chuck norris , bruce schneier");
Console.WriteLine("em 'chuck norris' e 'bruce schneier' colocar aspas");
Console.WriteLine();
Console.ResetColor();

string digitado = GetDigitado();

var cliente = new HttpClient();
string textoJson = await cliente.GetStringAsync($"http://api.icndb.com/jokes{digitado}");

var obj = JsonNode.Parse(textoJson);

Console.WriteLine();
Console.WriteLine("Joke: {0}", obj?["value"]?["joke"]);

Console.ResetColor();

string? GetDigitado()
{
    return Console.ReadLine();
}