﻿using System;

namespace Tabela
{
    class Program
    {
        static void Main(string[] args)
        {
             Console.WriteLine("Venda de Sorvete");
             Console.WriteLine("Qual sabor você quer?");
             var responde = Console.ReadLine();
             
        }
    }
}
