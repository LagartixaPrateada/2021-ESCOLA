﻿using System;

namespace Tarefa_02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bom dia sr.Hamamura, como se sente?");
            var responds = Console.ReadLine();
            Console.WriteLine($"{responds}? Já me senti assim antes... Aceita uma xícara de café, sr.Hamamura?");
            var respondsyn = Console.ReadLine();
            Console.WriteLine("Sinto muito, querendo ou não é impossível de dar uma xícara por aqui.");
        }
    }
}
