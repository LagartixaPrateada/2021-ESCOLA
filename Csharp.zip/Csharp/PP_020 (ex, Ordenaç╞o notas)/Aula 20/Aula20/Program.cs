﻿using System;
using System.IO;
using System.Linq;

namespace Aula_20
{
    class Program
    {
        static void Main(string[] args)
        {
           var arquivo = File.ReadLines("notas.txt");
           var arquivoOrdenado = arquivo.OrderBy((quebraLinha) => quebraLinha.Split(";")[0]);
           Console.ForegroundColor = ConsoleColor.Blue;
           Console.WriteLine("___________________");
           Console.WriteLine("Ordenação e Média |");
           Console.WriteLine("------------------|__________.");
           Console.ForegroundColor = ConsoleColor.Red;
           Console.Write("{0,-10} {1,-6} {2,10} ", "Nome", "Média", "Aprovação");
           Console.ForegroundColor = ConsoleColor.Blue;
           Console.WriteLine("|");
           Console.ResetColor();

           foreach (var quebraLinha in arquivoOrdenado)
           {
                string nome = quebraLinha.Split(";")[0];
                double notaUm = double.Parse(quebraLinha.Split(";")[1]);
                double notaDois = double.Parse(quebraLinha.Split(";")[2]);
                double notaTres = double.Parse(quebraLinha.Split(";")[3]);
                double notaQuatro = double.Parse(quebraLinha.Split(";")[4]);
                double media = Math.Round((notaUm + notaDois + notaTres + notaQuatro)/4, 1);

                string classifica;
                if (media >= 6)
                    classifica = "S";
                else
					classifica = "N";
                
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("{0,-10} {1,-5} {2,3}", nome, media, classifica);
                Console.ResetColor();
           }
        }
    }
}
//  Mariana Prata Leite CB3014312 148 CTII
