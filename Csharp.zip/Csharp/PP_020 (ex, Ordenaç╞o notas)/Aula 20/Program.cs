﻿using System;
using System.IO;
using System.Linq;

namespace Aula_20
{
    class Program
    {
        static void Main(string[] args)
        {
           var documento = File.ReadLines("notas.txt");
           var documento = documento.OrderBy((quebraLinha) => quebraLinha.Split(";")[0]);
           Console.WriteLine("{0,-10} {1,-6} {2,10} ", "Nome", "Média", "Aprovação");
           Console.WriteLine();

           foreach (var quebraLinha in documentoOrdenado)
           {
                string nome = quebraLinha.Split(";")[0];
                double notaUm = double.Parse(quebraLinha.Split(";")[1]);
                double notaDois = double.Parse(quebraLinha.Split(";")[2]);
                double notaTres = double.Parse(quebraLinha.Split(";")[3]);
                double notaQuatro = double.Parse(quebraLinha.Split(";")[4]);
                double media = Math.Round((notaUm + notaDois + notaTres + notaQuatro)/4, 1);

                string classifica;
                if (media >= 6)
                    classifica = "S";
                else
					classifica = "N";

                Console.WriteLine("{0,-10} {1,-5} {2,3}", nome, media, classifica);
           }
        }
    }
}
//  Mariana Prata Leite CB3014312 148 CTII
