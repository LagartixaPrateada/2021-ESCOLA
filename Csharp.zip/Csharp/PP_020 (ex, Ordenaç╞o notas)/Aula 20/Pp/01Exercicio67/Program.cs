﻿using System;

namespace _02Exercicio64
{
    class Program
    {
        static int EncontrarPosicao<T>(T[] vetor, int pos, bool asc = true)
        where T: IComparable
        {
            T elemento = vetor[pos];

            int posVerifica = pos - 1;
            while (posVerifica >= 0)
            {
                int comparacao = elemento.CompareTo(vetor[posVerifica]);
                comparacao *= asc ? 1 : -1;
                if (comparacao >= 0)
                    break;

                posVerifica--;
            }
            return posVerifica + 1;
            // vetor[posVerifica + 1] = elemento;
        }

        static void MovePosicao<T>(T[] vetor, int pos, int posFinal) 
        {
            T elemento = vetor[pos];

            for (int ii = pos; ii > posFinal; ii--)
            {
                vetor[ii] = vetor[ii - 1];
            }

            vetor[posFinal] = elemento;
        }

        static void InsertionSort<T, U, V>(T[] vetor, U[] vetor2, V[] vetor3, bool asc = true)
        where T: IComparable
        {
            for (int pos = 1; pos < vetor.Length; pos++)
            {
                int posFinal = EncontrarPosicao(vetor, pos, asc);
                MovePosicao(vetor, pos, posFinal);
                MovePosicao(vetor2, pos, posFinal);
                MovePosicao(vetor3, pos, posFinal);
            }
        }

        static void ImprimirVetor(string[] vetor, string[] vetor2, int[] vetor3)
        {
            for (int ii = 0; ii < vetor.Length; ii++)
            {
                Console.WriteLine("{0,10}{1,10}{2,10}", vetor[ii], vetor2[ii], vetor3[ii]);
            }
        }

        static void SolicitaEntrada(string[] nomes, string[] sexos, int[] idades)
        {
            for (int ii = 0; ii < nomes.Length; ii++)
            {
                Console.Write("Escreva o nome da {0}ª pessoa: ", ii + 1);
                nomes[ii] = Console.ReadLine();
                Console.Write("Digite o sexo da {0}ª pessoa: ", ii + 1);
                sexos[ii] = Console.ReadLine();
                Console.Write("Digite a idade da {0}ª pessoa: ", ii + 1);
                idades[ii] = int.Parse(Console.ReadLine());
            }
        }


        static void Main(string[] args)
        {
            const int qde = 20;
            var nomes = new string[qde];
            var sexos = new string[qde];
            var idades = new int[qde];
            SolicitaEntrada(nomes, sexos, idades);
            InsertionSort(nomes, sexos, idades);
            InsertionSort(idades, sexos, nomes, asc: false);
            InsertionSort(sexos, nomes, idades);
            ImprimirVetor(nomes, sexos, idades);
        }
    }
}
