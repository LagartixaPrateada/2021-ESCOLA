﻿using System;
using System.IO;
using System.Linq;

namespace _03OrdenaArquivoColunas
{
    class Program
    {
        static void Main(string[] args)
        {
            var leitor = File.ReadLines(args[0]);
            var leitorOrdenado = leitor.OrderByDescending(linha => int.Parse(linha.Split(",")[1]));

            foreach (var linha in leitorOrdenado)
            {
                Console.WriteLine(linha);
            }
        }
    }
}
