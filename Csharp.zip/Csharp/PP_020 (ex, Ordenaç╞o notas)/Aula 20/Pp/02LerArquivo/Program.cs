﻿using System;
using System.IO;
using System.Linq;

namespace _02LerArquivo
{
    class Program
    {
        static void Main(string[] args)
        {
            var leitor = File.ReadLines(args[0]);
            var leitorOrdenado = leitor.OrderBy(linha => linha);

            foreach (var linha in leitorOrdenado)
            {
                Console.WriteLine(linha);
            }
        }
    }
}
