﻿using System;

namespace ano
{
    class Program
    {
        static void Main(string[] args)
        {
            //Atividade 13
            //Armazenar dez valores na memória do computador em um vetor. Após a digitação dos valores, criar uma rotina para ler os valores e achar e exibir o maior deles.
            //const int de = 10;
            //var vetor = new int[de];
            //int maiorAtual = int.MinValue;
            //for (int ii = 0; ii < vetor.Length; ii++)
            //{
            //int valor;
            //    while (true)
            //    {
            //        Console.WriteLine("Valor da sequência: ");
            //        bool conseguiuT = int.TryParse(Console.ReadLine(), out valor);

            //       if (!conseguiuT)
            //        Console.WriteLine("Não é valido.");
            //        else
            //            break; 
            //    }
            
            //if (valor > maiorAtual)
            //    maiorAtual = valor;
            //}        
            //Console.WriteLine("O maior valor é {0}", maiorAtual);

            Console.WriteLine("Digite os valores da sequência:");

            int maiorAtual = int.MinValue;
            int valor;
            const int de = 10;
            int[] vetor = new int[de];
            for (int ii = 0; ii < vetor.Length; ii++)
            {
                while(true)
                {
                    Console.Write("{0}º valor: ", ii + 1);
                    bool transformou = int.TryParse(Console.ReadLine(), out valor);
                    if (transformou)
                        break;
                    else
                        Console.WriteLine("Não é válido.");
                }
                vetor[ii] = valor;
            }

            for (int ii = 0; ii < vetor.Length; ii++)
            {
              if (vetor[ii] > maiorAtual)
                maiorAtual = vetor[ii];
            }

            Console.WriteLine(string.Join(";", vetor));
            
            Console.WriteLine("O maior valor é {0}.", maiorAtual);
        }
    }
}
