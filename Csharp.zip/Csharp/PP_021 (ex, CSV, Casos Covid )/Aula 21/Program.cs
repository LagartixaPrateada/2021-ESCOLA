﻿using System;
using System.IO;
using CsvHelper;
using System.Linq;
using System.Globalization;
using CsvHelper.Configuration;

namespace Aula_21
{
    class Program
    { 
        static void Main(string[] args)
        {
            var config = new CsvConfiguration(CultureInfo.GetCultureInfo("en-US"))
            {
                Delimiter = ",",
            };
            
            var colunas = new 
            {
                date = string.Empty,
                state = string.Empty,
                city = string.Empty,
                place_type = string.Empty,
                confirmed = default(int?),
                deaths = default(int?),
                order_for_place = default(int?),
                is_last = default(bool),
                estimated_population_2019 = default(int?),
                estimated_population = default(int?),
                city_ibge_code = default(int?),
                confirmed_per_100k_inhabitants = default(double?),
                death_rate = default(double?),
            };
            
            using (var leitor = new StreamReader("casos_2021-10-26.csv"))
            using (var leitorCsv = new CsvReader(leitor, config))
            using (var escritor = new StreamWriter("casos_percentual.csv"))
            using (var escritorCsv = new CsvWriter(escritor, config))
            {
                var dados = leitorCsv.GetRecords(colunas);
                var filtrado = dados
                    .Where(item => item.place_type == "city" && item.estimated_population > 50000 )
                    .Select(item => new
                    {
                        item, infectada =
                        100 * Math.Round((decimal)(item.confirmed) / (decimal)item.estimated_population, 2)
                    })
                    .OrderByDescending(item => item.infectada);
                    escritorCsv.WriteRecords(filtrado);
            }
            //  CB3014312 CTII 148
            //  Fazer um leitor/escritor que calcule o percentual da população infectada nas cidades com mais de 50.000 habitantes.
            //  Grave o resultado em um arquivo CSV ordenado em ordem decrescente pelo percentual da população infectada.
        }
    }
}
