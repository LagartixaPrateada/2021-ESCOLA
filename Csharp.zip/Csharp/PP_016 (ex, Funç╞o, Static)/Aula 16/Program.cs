﻿using System;

namespace Aula_16
{
    class Program
    {
        //Mariana Prata Leite 148
        static double Calculo(double vpeso, double valtura)
        {
            double IMC;
            IMC = vpeso / Math.Pow(valtura, 2);
            return IMC;
        }
        static string Classifica(double IMC)
        {
            string classificaimc;
            if (IMC <= 18.5)
                classificaimc = "peso baixo";
            else if (IMC <=  24.9)
                classificaimc = "peso normal";
            else if (IMC <= 29.9)
                classificaimc = "sobrepeso";
            else if (IMC <= 34.9)
                classificaimc = "obesidade";
            else if (IMC <= 39.9)
                classificaimc = "obesidade severa";
            else
                classificaimc = "obesidade mórbida";

            return classificaimc;    
        }

        static void Main(string[] args)
        {
           int vpeso = int.Parse(args[0]);
           double valtura = double.Parse(args[1]);
           double IMC = Calculo(vpeso, valtura);
           string classificaimc = Classifica(IMC);

           Console.WriteLine("O seu IMC é {0}, você está em {1}.",  Math.Round(IMC, 2), classificaimc);
        }
    }
}
