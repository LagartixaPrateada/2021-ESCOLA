﻿using System;

namespace NOTA
{
    class Program
    {
        static void Main(string[] args)
        {
            double numero;
            while (true)
            {
                //Insira o número:
                Console.WriteLine("Insira o numero a ser multiplicado:");
                string entrada = Console.ReadLine();
                bool conseguiu = double.TryParse(entrada, out numero);

                if (conseguiu)
                break;
            }
            double multiplica;
            while (true)
            {
                //Insira o número:
                Console.WriteLine("Irá ser multiplicado até...:");
                string entradadois = Console.ReadLine();
                bool conseguiudois = double.TryParse(entradadois, out multiplica);

                if (conseguiudois)
                break;
            }
            
            double contador = 0;
            while (contador <= multiplica)
            {
              Console.WriteLine(contador * numero);
              contador++;
            }
            
        }
    }
}
