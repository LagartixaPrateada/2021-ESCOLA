﻿using System;

namespace Aula_17
{
    class Program
    {
        // Mariana Prata Leite 148 Programa - 17

        static void AlertaErro(string palavra, ConsoleColor cor = ConsoleColor.Red)
        {
            Console.ForegroundColor = cor; 
            Console.WriteLine(palavra);
            Console.ResetColor();
        }

        static double ReceberValores()
        {
            double valor;
            while (true)
            {
                Console.WriteLine("Me informe o valor:");
                bool transformarValor = double.TryParse(Console.ReadLine(), out valor);
                if (!transformarValor)
                    Console.WriteLine("Esse valor não é válido.");
                else
                    break;
            }
            return valor;
        }

        static double EscolherOperador(string operadorCalculo, double valor1, double valor2)
        {
            double resultadoCalculo = 0;
            switch (operadorCalculo)
            {   
                case "+":
                    resultadoCalculo = (valor1 + valor2);
                    break;
                case "-":
                    resultadoCalculo = (valor1 - valor2);
                    break;
                case "*":
                    resultadoCalculo = (valor1 * valor2);
                    break;
                case "/":
                    if (valor1 == 00 && valor2 == 00)
                    {
                        AlertaErro("Não é possível realizar essa operação, pois ela é inválida.");
                        break;
                    }
                    else
                        resultadoCalculo = (valor1 / valor2);
                        break;
                default:
                    Console.WriteLine("Operação desconhecida.");
                    break;
            }

            return resultadoCalculo;
        }

        static void Main(string[] args)
        {
            double valor1 = ReceberValores();
            double valor2 = ReceberValores();
            Console.WriteLine("Informe o operador a ser utilizado: (escolha entre +, -, * e /)");
            string operadorCalculo = Console.ReadLine();
            double resultadoCalculo = EscolherOperador(operadorCalculo, valor1, valor2);
            Console.WriteLine("{0} {1} {2} = {3}", valor1, operadorCalculo, valor2, resultadoCalculo);
        }
    }
}