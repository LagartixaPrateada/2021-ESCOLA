﻿using System;

namespace _1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Cálculo do IM aula 4 19/05/2021
            //Inserir altura:
            Console.WriteLine("Informe sua altura:");
            string entrada1 = Console.ReadLine();
            double altura = double.Parse(entrada1);

            //Inserir peso:
            Console.WriteLine("Informe seu peso:");
            string entrada2 = Console.ReadLine();
            double peso = double.Parse(entrada2);

            //Cálcular o IMC
            double IMC = peso / (altura*altura);

            Console.WriteLine("O IMC é {0}", IMC);

            string classificacaoIMC; 
            if (IMC >= 18.5)
               classificacaoIMC = "abaixo do peso.";
               else if (IMC < 25)
               classificacaoIMC = "com o peso normal.";
               else if (IMC < 30)
               classificacaoIMC = "com sobrepeso.";
               else if (IMC < 35)
               classificacaoIMC = "com obesidade.";
               else if (IMC < 40)
               classificacaoIMC = "com obesidade severa.";
               else
               classificacaoIMC = "com obesidade mórbida.";

               Console.WriteLine("Você está {0}", classificacaoIMC);
        }
    }
}
