﻿using System;

namespace _02MediaComparacao
{
    class Program
    {
        static void Main(string[] args)
        {
            // Solicitar a nota da etapa 1
            Console.Write("Insira a nota da etapa 1: ");
            string entrada1 = Console.ReadLine();
            double etapa1 = double.Parse(entrada1);

            // Solicitar a nota da etapa 2
            Console.Write("Insira a nota da etapa 2: ");
            string entrada2 = Console.ReadLine();
            double etapa2 = double.Parse(entrada2);

            // Solicitar a nota da etapa 3
            Console.Write("Insira a nota da etapa 3: ");
            string entrada3 = Console.ReadLine();
            double etapa3 = double.Parse(entrada3);

            // Solicitar a nota da etapa 4
            Console.Write("Insira a nota da etapa 4: ");
            string entrada4 = Console.ReadLine();
            double etapa4 = double.Parse(entrada4);

            
            // Calcular a média
            double media = (etapa1 + etapa2 + etapa3 + etapa4) / 4;
            
            // Imprimir se foi aprovado(a)
            string foiAprovad;
            if (media >= 6)
                foiAprovad = "Aprovado(a)";
            else
                foiAprovad = "Reprovado(a)";
                
            Console.WriteLine("{1} com a média {0}!", media, foiAprovad);

        }
    }
}
