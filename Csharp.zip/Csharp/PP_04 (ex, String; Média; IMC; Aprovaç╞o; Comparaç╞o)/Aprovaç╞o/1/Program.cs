﻿using System;

namespace _1
{
    class Program
    {
        static void Main(string[] args)
        {
            //19/05/21 Aprovação aula 4
            //Inserir notas...
            //Etapa 1:
            Console.WriteLine("Insira a nota 1:");
            string entrada1 = Console.ReadLine();
            double nota1 = double.Parse(entrada1);
            //Etapa 2:
            Console.WriteLine("Insira a nota 2:");
            string entrada2 = Console.ReadLine();
            double nota2 = double.Parse(entrada2);
            //Etapa 3:
            Console.WriteLine("Insira a nota 3:");
            string entrada3 = Console.ReadLine();
            double nota3 = double.Parse(entrada3);
            //Etapa 4:
            Console.WriteLine("Insira a nota 4:");
            string entrada4 = Console.ReadLine();
            double nota4 = double.Parse(entrada4);

            //Cálcular a Média...
            double Média = (nota1 + nota2 + nota3 + nota4) / 4;
         
            string aprovação; 
            if (Média >= 6 )
                  aprovação = "aprovação.";
            else 
                  aprovação = "reprovação.";
                 
                Console.WriteLine("Com média {1} teve {0}", aprovação, Média);
           
        }
    }
}
