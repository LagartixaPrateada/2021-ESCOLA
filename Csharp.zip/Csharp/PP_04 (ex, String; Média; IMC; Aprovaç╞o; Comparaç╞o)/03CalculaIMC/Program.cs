﻿using System;

namespace _03CalculaIMC
{
    class Program
    {
        static void Main(string[] args)
        {
            // Solicitar o peso
            Console.Write("Digite o peso em kg: ");
            string entrada = Console.ReadLine();
            double peso = double.Parse(entrada);

            // Solicitar a altura
            Console.Write("Digite o altura em metros: ");
            entrada = Console.ReadLine();
            double altura = double.Parse(entrada);

            // Calcular o IMC
            double imc = peso / Math.Pow(altura, 2);

            // Mostrar o IMC e a classificação
            Console.WriteLine("O IMC é {0}", imc);

            string classificacaoIMC;
            if (imc < 18.5)
                classificacaoIMC = "peso baixo";
            else if (imc < 25)
                classificacaoIMC = "peso normal";
            else if (imc < 30)
                classificacaoIMC = "sobrepeso";
            else if (imc < 35)
                classificacaoIMC = "obesidade";
            else if (imc < 40)
                classificacaoIMC = "obesidade severa";
            else
                classificacaoIMC = "obesidade mórbida";
            

            Console.WriteLine("A classificação desse IMC é: {0}", classificacaoIMC);
        }
    }
}
