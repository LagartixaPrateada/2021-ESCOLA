﻿using System;

namespace _01ComparacaoString
{
    class Program
    {
        static void Main(string[] args)
        {
            string mensagem = "Saber utilizar a estrutura de seleção na linguagem C#";

            Console.WriteLine(mensagem == "Saber utilizar a estrutura de seleção na linguagem C#");

            // Começa com
            Console.WriteLine(mensagem.StartsWith("Saber"));
            Console.WriteLine(mensagem.StartsWith("Saber a"));

            // Contém
            Console.WriteLine(mensagem.Contains("utura"));


            bool ehIgual = mensagem == "Saber utilizar a estrutura de seleção na linguagem C#";

            Console.WriteLine("As mensagens são iguais? {0}", ehIgual);
        }
    }
}
