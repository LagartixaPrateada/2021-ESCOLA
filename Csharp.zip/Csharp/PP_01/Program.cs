﻿using System;

namespace Meu_Primeiro_Programa
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Olá, o que faz por aqui?");
            var responds = Console.ReadLine();
            Console.WriteLine("Bacana, qual é o seu nome?");
            var name = Console.ReadLine(); 
            Console.WriteLine("Seus familiares tem bom gosto! Quais seus hobbies?"); 
            var respondstwo = Console.ReadLine(); 
            Console.WriteLine("Você parece uma pessoa legal, gostaria de ser sua amiga. Que tal?");
            var respondsthree = Console.ReadLine();
            Console.WriteLine("Haha, ok então... Oh! Eu disse meu nome?");
            var respondsfour = Console.ReadLine();
            Console.WriteLine("Me esqueci... Bom, me chamo Lagartixa Prateada prazer!"); 
            Console.WriteLine("Não vá embora ainda, tenho uma piada... Você conhece a piada do pônei?");
            var respondsfive = Console.ReadLine();
            Console.WriteLine("Pô nei eu! Hahaha.");
            var respondsix = Console.ReadLine();
            Console.WriteLine("Desculpe haha, ainda não sou uma boa comediante né?");
            var respondsseven = Console.ReadLine();
            Console.WriteLine("Bom, é a vida. Que tal um adeus?");
            var respondseight = Console.ReadLine();
            Console.WriteLine("Realmente tenho que ir, meu tempo por aqui acabou... Byebye my friend!");
        }
    }
}
