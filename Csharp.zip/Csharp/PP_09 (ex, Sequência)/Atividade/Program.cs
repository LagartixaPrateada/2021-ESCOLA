﻿using System;

namespace Atividade
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            const int limite = 50;
            int elementos;
            while (true)
            {
                Console.WriteLine("Quantidade de elementos da sequência a serem somados:");
                bool conseguiutransformar = int.TryParse(Console.ReadLine(), out elementos);

                if(!conseguiutransformar)
                Console.WriteLine("Inválido.");
                else if (elementos < 0)
                Console.WriteLine("O valor não pode ser negativo");
                else if (elementos > limite)
                Console.WriteLine("O limite é 50.");
                else 
                break;
            }
            Console.ResetColor();
            double numerador = 1;
            double denominador = 2;
            double valor = 0;

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("");

            for (int ii = 0; ii < elementos; ii++)
            {
                Console.WriteLine("{0}/{1}  ", numerador, denominador);
                valor += numerador / denominador;
                numerador++;
                denominador++;
            }
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("A soma até o {0}° elemento da sequência...",elementos);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(valor);
            Console.ResetColor();
        }
    }
}
