﻿using System;
using System.Linq;

namespace Aula_14
{
    class Program
    {
        static void Main(string[] args)
        {
            int ele;
            const int de = 20;
            while (true)
            {
                Console.WriteLine("Quantidade de elementos:");
                bool conseguiutr = int.TryParse(Console.ReadLine(), out ele);
                
                if (!conseguiutr)
                    Console.WriteLine("Elemento inválido.");
                    else if (ele < 0)
                    Console.WriteLine("Os elementos precisam ser positivos.");
                    else if (ele > de)
                    Console.WriteLine("O elemento precissa ser menor que 20.");
                    else
                    break;
            }
        

            double[] vetor = new double[ele];
            double valor;
            for (int ii = 0; ii < ele; ii++)
            {
                while (true)
                {
                    Console.WriteLine("Valor na sequência: ");
                    bool conseguiuT = double.TryParse(Console.ReadLine(), out valor);

                    if (!conseguiuT)
                    Console.WriteLine("Não é valido.");
                    else
                        break; 
                }
                vetor[ii] = valor;
            }

            double soma = vetor.Sum();
            double media = vetor.Average();
            double menor = vetor.Min();
            double maior = vetor.Max();
            int vn = vetor.Count(item => item > 0);
            int vp = vetor.Count(item => item < 0);

            int pp;
            int pn;
            pp = (vp*100)/ele;
            pn = (vn*100)/ele;

            Console.WriteLine("O maior valor é {0}", maior);
            Console.WriteLine("O menor valor é {0}", menor);
            Console.WriteLine("A soma dos valores digitados é {0}", soma);
            Console.WriteLine("A média dos valores é {0}", media);
            Console.WriteLine("A porcentagem de valor negativos é {0}%", pp);
            Console.WriteLine("A porcentagem de valor positivos é {0}%", pn);



        }
    }
}
