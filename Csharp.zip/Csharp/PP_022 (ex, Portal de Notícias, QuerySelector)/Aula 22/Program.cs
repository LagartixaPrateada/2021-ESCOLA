﻿using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.IO;
using System.Net;
using System;

namespace Aula_22
{
    class Program
    {
        static string url = "https://cbt.ifsp.edu.br/";

        static void Main(string[] args)
        {
            string html = File.ReadAllText("ifsp.html");
            var leitor = new AngleSharp.Html.Parser.HtmlParser();
            var document = leitor.ParseDocument(html);
            var links = document.QuerySelectorAll(".chamadas-secundarias > div > h3 > a");

            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("ÚLTIMAS NOTÍCIAS");
            Console.ResetColor();

            foreach (var item in links)
            {
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Blue;
                string link = item.GetAttribute("href");
                string nome = item.InnerHtml;
                Console.WriteLine("{0}:", nome.Trim());
                Console.ResetColor();
                Console.WriteLine("{0}{1}", url, link);
                Console.WriteLine();
            }
        }
    }
}
