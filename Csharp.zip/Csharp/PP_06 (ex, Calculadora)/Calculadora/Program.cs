﻿using System;

namespace Calculadora
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Me informe o primeiro valor:");
            double valor = double.Parse(Console.ReadLine());

            Console.WriteLine("Me informe o segundo valor:");
            double svalor = double.Parse(Console.ReadLine());

            Console.WriteLine("Qual a opreração? (Responda em: + - / *)");
            string operador = Console.ReadLine();

            double resultado;
            switch (operador)
            {
                case "+":
                resultado = (valor+svalor);
                Console.WriteLine("O resultado é {0}", resultado);
                break;
                case "-":
                resultado = (valor-svalor);
                Console.WriteLine("O resultado é {0}", resultado);
                break;
                case "*":
                resultado = (valor*svalor);
                Console.WriteLine("O resultado é {0}", resultado);
                break;
                case "/":
				if (svalor == 0)
				{
                Console.WriteLine("Operação inválida.");   
				
                return;
				}
                resultado = (valor/svalor);
                Console.WriteLine("O resultado é {0}", resultado);
                break;
                default:
                Console.WriteLine("Operador desconhecido");
                return;
            }            
        
              
        }
    }
}
