﻿using System;

namespace Aula_18
{
    class Program
    {
        static void PalavraColorida(string palavra, ConsoleColor cor = ConsoleColor.Yellow) 
        {   
            Console.ForegroundColor = cor;
            Console.WriteLine(palavra);
            Console.ResetColor();
        }
        static void ExibicaoVetor(int[] vetor)
        {
            for (int mi = 0; mi < vetor.Length; mi++) 
            {
            Console.Write(vetor[mi] + " ");  
            }
        }    
        static void SelectionSort(int[] vetor)
        {
            int menor, menorValor = 0;

            for (int mi = 0; mi < vetor.Length; mi++)
            {
                menor = mi;

                for(int ri = mi + 1; ri < vetor.Length; ri++)
                {
                    if(vetor[ri] < vetor[menor])
                    {
                        menor = ri;
                    }
                }
                menorValor = vetor[menor];
                vetor[menor] = vetor[mi];
                vetor[mi] = menorValor;
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("  ");
            Console.WriteLine("Ordenação Selection Sort");
            int[] vetor = {2, 6, 3, 0, 1, 8, 5, 4, 10, 7};
            PalavraColorida("Vetor desordenado:  ");
            ExibicaoVetor(vetor);
            Console.WriteLine("  ");
            Console.WriteLine("Ordenando...  ");
            SelectionSort(vetor);
            PalavraColorida("Vetor ordenado:  ");
            ExibicaoVetor(vetor);
            Console.WriteLine("  ");
        }
    }
}

