﻿using System;

namespace Anotação
{
    class Program
    {
        static void Main(string[] args)
        {
            //var
            int ele;
            const int de = 20;
            while (true)
            {
                Console.WriteLine("Quantidade de elementos:");
                bool conseguiutr = int.TryParse(Console.ReadLine(), out ele);
                
                if (!conseguiutr)
                    Console.WriteLine("Elemento inválido.");
                    else if (ele < 0)
                    Console.WriteLine("Os elementos precisam ser positivos.");
                    else if (ele > de)
                    Console.WriteLine("O elemento precissa ser menor que 20.");
                    else
                    break;
            }
            int maiorAtual = int.MinValue;
            int menorAtual =  int.MaxValue;
            int soma = 0;
            int vn = 0;
            int vp = 0;
            for (int ii = 0; ii < ele; ii++)
            {
                int valor;
                while (true)
                {
                    Console.WriteLine("Valor da sequência: ");
                    bool conseguiuT = int.TryParse(Console.ReadLine(), out valor);

                    if (!conseguiuT)
                    Console.WriteLine("Não é valido.");
                    else
                        break; 
                }
               
            soma = soma + valor;
            if (valor > maiorAtual)
                    maiorAtual = valor;
			if (valor < menorAtual)
					menorAtual = valor;

            if (valor > 0)
            vp++;
            if (valor < 0)
            vn++;  
            }

            int pp;
            int pn;
            pp = (vp*100)/ele;
            pn = (vn*100)/ele;

            double media = soma/ele;

            Console.WriteLine("O maior valor é {0}", maiorAtual);
            Console.WriteLine("O menor valor é {0}", menorAtual);
            Console.WriteLine("A soma dos valores digitados é {0}", soma);
            Console.WriteLine("A média dos valores é {0}", media);
            Console.WriteLine("A porcentagem de valor negativos é {0}%", pn);
            Console.WriteLine("A porcentagem de valor positivos é {0}%", pp);

        }
    }
}
