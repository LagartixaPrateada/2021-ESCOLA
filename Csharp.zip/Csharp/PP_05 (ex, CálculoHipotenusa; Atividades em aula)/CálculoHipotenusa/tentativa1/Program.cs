﻿using System;

namespace tentativa1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Exercicío 3 classificar triangulo:
            Console.WriteLine("Me informe as medidas:");
            int lado1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Me informe as medidas:");
            int lado2 = int.Parse(Console.ReadLine());

            Console.WriteLine("Me informe as medidas:");
            int lado3 = int.Parse(Console.ReadLine());

            //É triângulo?
            if (lado2 + lado3 > lado1 &&
                lado1 + lado3 > lado2 &&
                lado1 + lado2 > lado3)
            {
                Console.WriteLine("Essas medidas podem formar um triângulo.");

                //Qual o tipo?
                if (lado1 == lado2 && lado2 == lado3)
                    Console.WriteLine("O triângulo é equilátero.");
                else if (lado1 == lado2 || lado2 == lado3 || lado1 == lado3)    
                    Console.WriteLine("É um triângulo isóceles.");
                else 
                    Console.WriteLine("O triângulo é escaleno.");
            }
            else 
            {
                Console.WriteLine("Essas medidas não formam um triângulo.");
            }

            //Exercicío 3 Avaliação grupo de risco:
            //Solicitar:
            Console.WriteLine("Sua idade:");
            int idade = int.Parse(Console.ReadLine());
            if (idade >= 60)
            {
                Console.WriteLine("Você faz parte do grupo de risco, fique em casa.");
                return;
            }

            Console.WriteLine("Sua altura:");
            double altura = double.Parse(Console.ReadLine());
            Console.WriteLine("Seu peso:");
            double peso = double.Parse(Console.ReadLine());

            //Doenças:
            Console.WriteLine("Possui doença Cardiovascular (S/N):");
            string resposta1 = Consoleonsole.ReadLine().ToUpper();
            Console.WriteLine("Asma grave? (S/N):");
            string resposta2 = Consoleonsole.ReadLine().ToUpper();
            Console.WriteLine("Diabetes? (S/N):");
            string resposta3 = Consoleonsole.ReadLine().ToUpper();
            Console.WriteLine("Hipertensão? (S/N):");
            string resposta4 = Consoleonsole.ReadLine().ToUpper();

            //Calcular IMC
            double imc = peso/(altura*altura);

            if (idade >= 60 ||
                resposta1 == "S" ||
                resposta2 == "S" ||
                resposta3 == "S"
                resposta4 == "S")
                {
                    Console.WriteLine("Cuidado, você é grupo de risco para COVID-19.");
                }    
                    else
                    Console.WriteLine("Você não é do grupo de risco, mas deve ficar em casa.");
            

        }
    }
}
