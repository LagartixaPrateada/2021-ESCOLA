﻿using System;

namespace Maior_numb
{
    class Program
    {
        static void Main(string[] args)
        {
             //Exercicío 1 Solicite e descubra o maior número:
            Console.WriteLine("Me diga um número");
            int numbone = int.Parse(Console.ReadLine());

            Console.WriteLine("Me diga outro número");
            int numbtwo = int.Parse(Console.ReadLine());

            int maiornumb; 
            if (numbone > numbtwo)
                maiornumb = numbone;

            else     
                maiornumb = numbtwo;

                Console.WriteLine("O maior número é: {0}", maiornumb);
        }
    }
}
