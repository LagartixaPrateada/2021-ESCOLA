﻿using System;

namespace Hipotenusa
{
    class Program
    {
        static void Main(string[] args)
        {
            //CalcHipostenusa 
            //26/05/2021
            Console.WriteLine("Me diga o valor A:");
            int A = int.Parse(Console.ReadLine());

            Console.WriteLine("Me diga o valor B:");
            int B = int.Parse(Console.ReadLine());

            Console.WriteLine("Me diga o valor C:");
            int C = int.Parse(Console.ReadLine());

            //É triângulo?
            if (B + C > A &&
                A + C > B &&
                A + B > C)
                {
                    Console.WriteLine("É um triângulo.");
                    if (A == B && B == C)
                    Console.WriteLine("O triângulo é equilátero.");
                    else if (A == B || B == C || A == C)
                    Console.WriteLine("É triângulo isóceles.");
                    else
                    Console.WriteLine("O triângulo é escaleno.");
                }
                else 
                {
                    Console.WriteLine("Não é triângulo.");
                    return;
                }

             int hip;
             int cateto1;
             int cateto2;

            if (A > B && A > C)
            {
            hip = A;
            cateto1 = B; 
            cateto2 = C;
            }
            else if (B > A && B > C)
            {
            hip = B;
            cateto1 = A;
            cateto2 = C;
            }
            else 
            {
            hip = C;
            cateto1 = A;
            cateto2 = B;
            }

            if (cateto1*cateto1 + cateto2*cateto2 == hip*hip)
            Console.WriteLine("O triângulo é retângulo");

            else
            {
                Console.WriteLine("O triângulo não é retângulo");
            }

            


        }
    }
}
