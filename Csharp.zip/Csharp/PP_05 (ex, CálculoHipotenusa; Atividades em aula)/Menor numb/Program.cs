﻿using System;

namespace Menor_numb
{
    class Program
    {
        static void Main(string[] args)
        {
            //Exercicío 2 Menor número:
            Console.WriteLine("Me diga um número:");
            int numbone1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Me diga outro número:");
            int numbtwo2 = int.Parse(Console.ReadLine());

            Console.WriteLine("Me diga um outro número:");
            int numbthree = int.Parse(Console.ReadLine());

            int menor;
            if (numbone1 < numbtwo2 && numbone1 < numbthree)
            menor = numbone1;   
            else if (numbtwo2 < numbone1 && numbtwo2 < numbthree)
            menor = numbtwo2;
            else 
            menor = numbthree;

            Console.WriteLine("Menor número entre {0}, {1} e {2} é {3}", numbone1, numbtwo2, numbthree, menor);
        }
    }
}
