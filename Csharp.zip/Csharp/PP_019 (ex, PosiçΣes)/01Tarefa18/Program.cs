﻿using System;

namespace _01Tarefa18
{
    class Program
    {
        static int EncontraPosMenor(int[] vetor, int pos)
        {
            int posMenor = pos;

            for (int ii = pos + 1; ii < vetor.Length; ii++)
            {
                if (vetor[ii] < vetor[posMenor])
                    posMenor = ii;
            }

            return posMenor;
        }

        static void TrocaPosicao(int[] vetor, int pos1, int pos2)
        {
            int temp = vetor[pos1];
            vetor[pos1] = vetor[pos2];
            vetor[pos2] = temp;
        }
        static void SelectionSort(int[] vetor)
        {
            for (int pos = 0; pos < vetor.Length; pos++)
            {
                int posMenor = EncontraPosMenor(vetor, pos);
                TrocaPosicao(vetor, pos, posMenor);
            }
        }

        static void ImprimirVetor(int[] vetor)
        {
            foreach (var item in vetor)
            {
                Console.Write("| {0} |", item);
            }
            Console.WriteLine();
        }

        static void Main(string[] args)
        {
            int[] vetor = {2, 6, 3, 0, 1, 8, 5, 4, 10, 7};
            
            Console.WriteLine("Vetor original: ");
            ImprimirVetor(vetor);

            SelectionSort(vetor);
            Console.WriteLine("Vetor ordenado: ");
            ImprimirVetor(vetor);
        }
    }
}
