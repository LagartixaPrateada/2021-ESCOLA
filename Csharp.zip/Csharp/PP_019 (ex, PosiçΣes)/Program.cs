﻿using System;

namespace Aula19
{
    class Program
    {
        //Mariana Prata Leite CTII 148
        static void PosicaoTroca(int[] vetor, int pos1, int pos2)
        {
            int temporario = vetor[pos1];
            vetor[pos1] = vetor[pos2];
            vetor[pos2] = temporario;
        }
        static int PosicaoVolta(string[] vetor, int pos)
        {
            string ElementoVolta = vetor[pos];

            int jj;
            for (jj = (pos - 1); jj >= 0; jj--)
            {
                if (ElementoVolta.CompareTo(vetor[jj]) >= 0)
                    break;
            }

            return jj + 1;
        }
        static int PosicaoVolta(int[] vetor, int pos)
        {
            int ElementoVolta = vetor[pos];

            int jj;
            for (jj = (pos - 1); jj >= 0; jj--)
            {
                if (ElementoVolta.CompareTo(vetor[jj]) <= 0)
                    break;
            }

            return jj + 1;
        }
        static void PegarPosicao(string[] vetor, int pos, int PosicaoFinal)
        {
            string ElementoVolta = vetor[pos];

            int ii;
            for (ii = pos - 1; ii >= PosicaoFinal; ii--)
            {
                vetor[ii + 1] = vetor[ii];
            }

            vetor[ii + 1] = ElementoVolta;
        }
        static void PegarPosicao(int[] vetor, int pos, int PosicaoFinal)
        {
            int ElementoVolta = vetor[pos];

            int ii;
            for (ii = pos - 1; ii >= PosicaoFinal; ii--)
            {
                vetor[ii + 1] = vetor[ii];
            }

            vetor[ii + 1] = ElementoVolta;
        }
        // Insertion Sorts:
        static void InsertionSort( string[] vetor, int[] vetorUm, string[] vetorDois )
        {
            for (int ii = 1; ii < vetor.Length; ii++)
            {
                string ElementoVolta = vetor[ii];
                int PosicaoFinal = PosicaoVolta(vetor, ii);
                PegarPosicao(vetor, ii, PosicaoFinal);
                PegarPosicao(vetorUm, ii, PosicaoFinal);
                PegarPosicao(vetorDois, ii, PosicaoFinal);
            }
        }
        static void InsertionSort( int[] vetor, string[] vetorUm, string[] vetorDois )
        {
            for (int ii = 1; ii < vetor.Length; ii++)
            {
                int ElementoVolta = vetor[ii];
                int PosicaoFinal = PosicaoVolta(vetor, ii);
                PegarPosicao(vetor, ii, PosicaoFinal);
                PegarPosicao(vetorUm, ii, PosicaoFinal);
                PegarPosicao(vetorDois, ii, PosicaoFinal);
            }
        }
        static void InsertionSort( string[] vetor, string[] vetorUm, int[] vetorDois )
        {
            for (int ii = 1; ii < vetor.Length; ii++)
            {
                string ElementoVolta = vetor[ii];
                int PosicaoFinal = PosicaoVolta(vetor, ii);
                PegarPosicao(vetor, ii, PosicaoFinal);
                PegarPosicao(vetorUm, ii, PosicaoFinal);
                PegarPosicao(vetorDois, ii, PosicaoFinal);
            }
        }
        // Solicitar entrada e exibir
        static void SolicitacaoDeEntradas(string[] nome, string[] sexo, int[] idade)
        {
            for (int ii = 0; ii < nome.Length; ii++)
            {
                Console.Write("Digite o nome da {0}º pessoa: ", ii + 1);
                nome[ii] = Console.ReadLine();
                Console.Write("Digite o sexo da {0}ª pessoa: ", ii + 1);
                sexo[ii] = Console.ReadLine();
                Console.Write("Digite a idade da {0}ª pessoa: ", ii + 1);
                idade[ii] = int.Parse(Console.ReadLine());
            }
        }
        static void Exibir(string[] vetor, string[] vetorDois, int[] vetorTres) 
        {
            Console.WriteLine();
            Console.WriteLine("Tabela reorganizada | ");
            Console.WriteLine();
            for (int ii = 0; ii < vetor.Length; ii++)
            {
                Console.WriteLine("{0,10}{1,5}{2,5}", vetor[ii], vetorDois[ii], vetorTres[ii]);
            }
        }
        static void Main(string[] args)
        {
            var sexo = new string[20];
            var nome = new string[20];
            var idade = new int[20];

            Console.WriteLine("Reorganização | ");
            Console.WriteLine();          
            
            SolicitacaoDeEntradas(nome, sexo, idade);

            InsertionSort(idade, nome, sexo);
            InsertionSort(sexo, idade, nome);
            InsertionSort(nome, sexo, idade);
            InsertionSort(sexo, nome, idade);
            InsertionSort(idade, nome, sexo);
            InsertionSort(sexo, nome, idade);

            Exibir(nome, sexo, idade);
        }
    }
}