﻿using System;

namespace _02Exercicio64
{
    class Program
    {
        static int EncontrarPosicao(string[] vetor, int pos)
        {
            string elemento = vetor[pos];

            int posVerifica = pos - 1;
            while (posVerifica >= 0)
            {
                if (elemento.CompareTo(vetor[posVerifica]) >= 0)
                    break;

                posVerifica--;
            }
            return posVerifica + 1;
            // vetor[posVerifica + 1] = elemento;
        }

        static void MovePosicao(string[] vetor, int pos, int posFinal) 
        {
            string elemento = vetor[pos];

            for (int ii = pos; ii > posFinal; ii--)
            {
                vetor[ii] = vetor[ii - 1];
            }

            vetor[posFinal] = elemento;
        }

        static void MovePosicao(int[] vetor, int pos, int posFinal) 
        {
            int elemento = vetor[pos];

            for (int ii = pos; ii > posFinal; ii--)
            {
                vetor[ii] = vetor[ii - 1];
            }

            vetor[posFinal] = elemento;
        }

        static void InsertionSort(string[] vetor, string[] vetor2, int[] vetor3)
        {
            for (int pos = 1; pos < vetor.Length; pos++)
            {
                int posFinal = EncontrarPosicao(vetor, pos);
                MovePosicao(vetor, pos, posFinal);
                MovePosicao(vetor2, pos, posFinal);
                MovePosicao(vetor3, pos, posFinal);
            }
        }
        
        // EncontrarPosicao(int[] vetor, int pos, int posFinal) -- decrescente!
        // InsertionSort(int[] vetor, string[] vetor2, string[] vetor3)

        static void ImprimirVetor(string[] vetor, string[] vetor2, int[] vetor3)
        {
            for (int ii = 0; ii < vetor.Length; ii++)
            {
                Console.WriteLine("{0,10}{1,10}{2,10}", vetor[ii], vetor2[ii], vetor3[ii]);
            }
        }

        static void SolicitaEntrada(string[] nomes, string[] sexos, int[] idades)
        {
            for (int ii = 0; ii < nomes.Length; ii++)
            {
                Console.Write("Escreva o nome da {0}ª pessoa: ", ii + 1);
                nomes[ii] = Console.ReadLine();
                Console.Write("Digite o sexo da {0}ª pessoa: ", ii + 1);
                sexos[ii] = Console.ReadLine();
                Console.Write("Digite a idade da {0}ª pessoa: ", ii + 1);
                idades[ii] = int.Parse(Console.ReadLine());
            }
        }


        static void Main(string[] args)
        {
            const int qde = 20;
            var nomes = new string[qde];
            var sexos = new string[qde];
            var idades = new int[qde];
            SolicitaEntrada(nomes, sexos, idades);
            InsertionSort(nomes, sexos, idades);
            // InsertionSort(idades, sexos, nomes);
            InsertionSort(sexos, nomes, idades);
            ImprimirVetor(nomes, sexos, idades);
        }
    }
}
