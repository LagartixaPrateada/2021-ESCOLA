﻿using System;

namespace _02Exercicio64
{
    class Program
    {
        static int EncontraPosMenor(string[] vetor, int pos)
        {
            int posMenor = pos;

            for (int ii = pos + 1; ii < vetor.Length; ii++)
            {
                if (vetor[ii].CompareTo(vetor[posMenor]) == -1)
                    posMenor = ii;
            }

            return posMenor;
        }

        static void TrocaPosicao(string[] vetor, int pos1, int pos2)
        {
            string temp = vetor[pos1];
            vetor[pos1] = vetor[pos2];
            vetor[pos2] = temp;
        }
        static void SelectionSort(string[] vetor)
        {
            for (int pos = 0; pos < vetor.Length; pos++)
            {
                int posMenor = EncontraPosMenor(vetor, pos);
                TrocaPosicao(vetor, pos, posMenor);
            }
        }

        static void ImprimirVetor(string[] vetor)
        {
            foreach (var item in vetor)
            {
                Console.WriteLine(item);
            }
        }

        static string[] SolicitaEntrada()
        {
            var nomes = new string[20];

            for (int ii = 0; ii < nomes.Length; ii++)
            {
                Console.Write("Escreva o nome da {0}ª pessoa: ", ii + 1);
                nomes[ii] = Console.ReadLine();
            }

            return nomes;
        }


        static void Main(string[] args)
        {
            string[] nomes = SolicitaNomes();
            SelectionSort(nomes);
            ImprimirVetor(nomes);
        }
    }
}
