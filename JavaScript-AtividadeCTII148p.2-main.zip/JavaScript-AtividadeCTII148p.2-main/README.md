# JavaScript-AtividadeCTII148p.2
CB3014312 | 25/10/21 | CTII148 | Refaça, da lista solicitada na atividade anterior, os exercícios 5, 13 e 17.
