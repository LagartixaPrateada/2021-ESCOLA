# JogodaVelha-JavaScript
Implementar um código HTML/Javascript que execute um "JOGO DA VELHA".  Baseie-se no projeto do teatro para codificar o evento click dos botões. Utilizar ARRAY no projeto.  Bom divertimento e até o ano que vem!!!
